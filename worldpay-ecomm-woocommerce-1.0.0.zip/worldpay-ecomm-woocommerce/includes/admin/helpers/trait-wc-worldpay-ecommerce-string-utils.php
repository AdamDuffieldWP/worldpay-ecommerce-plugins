<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait WC_Worldpay_Ecommerce_String_Utils {

	public function limit( $value, $limit = 100, $end = '...' ) {
		if ( mb_strwidth( $value, 'UTF-8' ) <= $limit ) {
			return $value;
		}

		return rtrim( mb_strimwidth( $value, 0, $limit, '', 'UTF-8' ) ) . $end;
	}

	public function mask( $string, $character, $index, $length = null, $encoding = 'UTF-8' ) {
		if ( $character === '' ) {
			return $string;
		}

		$segment = mb_substr( $string, $index, $length, $encoding );

		if ( $segment === '' ) {
			return $string;
		}

		$strlen      = mb_strlen( $string, $encoding );
		$start_index = $index;

		if ( $index < 0 ) {
			$start_index = $index < - $strlen ? 0 : $strlen + $index;
		}

		$start       = mb_substr( $string, 0, $start_index, $encoding );
		$segment_len = mb_strlen( $segment, $encoding );
		$end         = mb_substr( $string, $start_index + $segment_len );

		return $start . str_repeat( mb_substr( $character, 0, 1, $encoding ), $segment_len ) . $end;
	}

	public function length( $value, $encoding = null ) {
		return mb_strlen( $value, $encoding );
	}
}
