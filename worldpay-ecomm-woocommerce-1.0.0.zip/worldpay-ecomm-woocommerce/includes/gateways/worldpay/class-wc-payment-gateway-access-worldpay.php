<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Worldpay\Api\Entities\Event;
use Worldpay\Api\Enums\EventType;
use Worldpay\Api\Enums\RequestMethods;
use Worldpay\Api\Enums\WebhookIPWhiteList;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ShippingAddress;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\AccessWorldpay;

/**
 * WC_Payment_Gateway_Access_Worldpay class.
 */
class WC_Payment_Gateway_Access_Worldpay extends WC_Payment_Gateway {

	use WC_Access_Worldpay_Field_Validators;
	use WC_Worldpay_Ecommerce_String_Utils;

	/**
	 * Initialize payment method gateway.
	 */
	public function __construct() {
		$this->id                 = 'access_worldpay_hpp';
		$this->icon               = '';
		$this->has_fields         = false;
		$this->method_title       = __( 'Worldpay Payments', 'worldpay-gateway-woocommerce' );
		$this->method_description = __( 'Accept payments via Worldpay.', 'worldpay-gateway-woocommerce' );
		$this->supports           = array( 'refunds' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		add_filter( 'woocommerce_generate_masked_totally_html', array( $this, 'generate_masked_totally_html' ) );
		add_filter( 'woocommerce_generate_masked_partially_html', array( $this, 'generate_masked_partially_html' ) );

		$error = empty( $_GET[ $this->id ] ) ? '' : wc_clean( wp_unslash( $_GET[ $this->id ] ) );
		if ( ! empty( $error ) ) {
			add_filter( 'woocommerce_before_checkout_form', function () {
				wc_print_notice( 'Something went wrong while processing your payment. Please try again.', 'error' );
			} );
			add_filter( 'woocommerce_pay_order_before_payment', function () {
				wc_print_notice( 'Something went wrong while processing your payment. Please try again.', 'error' );
			} );

		}

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id,
			array( $this, 'process_admin_options' ) );

		add_action( 'woocommerce_api_worldpay_results', array( $this, 'process_payment_result_url' ) );

		if ( wc_bool_to_string( $this->get_option( 'app_webhooks' ) ) ) {
			add_action( 'woocommerce_api_worldpay_events', array( $this, 'process_event' ) );
		}
	}

	/**
	 * Process status updates received from Access Worldpay via webhooks.
	 *
	 * @return void
	 */
	public function process_event() {
		$data_to_log = array(
			'requestType' => 'webhook',
		);

		WC_Worldpay_Ecommerce_Woocommerce::include_sdk();

		try {
			if ( ( ! in_array( $_SERVER['REMOTE_ADDR'], WebhookIPWhiteList::IPS, true ) ) ) {
				$data_to_log['requestIP'] = $_SERVER['REMOTE_ADDR'];
				throw new \Exception( 'Request IP not found in IP whitelist.' );
			}
			if ( ( RequestMethods::POST !== $_SERVER['REQUEST_METHOD'] ) ) {
				$data_to_log['requestMethod'] = $_SERVER['REQUEST_METHOD'];
				throw new \Exception( 'Request method not supported.' );
			}

			$server      = rest_get_server();
			$headers     = $server->get_headers( wp_unslash( $_SERVER ) );
			$raw_content = $server::get_raw_data();

			$event = new Event( $raw_content );

			$data_to_log['eventId']              = $event->id;
			$data_to_log['eventType']            = $event->type;
			$data_to_log['transactionReference'] = $event->transactionReference;

			if ( ! in_array( $event->type, array(
				EventType::SENT_FOR_SETTLEMENT,
				EventType::ERROR,
				EventType::REFUSED,
				EventType::SENT_FOR_REFUND,
				EventType::REFUND_FAILED
			) ) ) {
				throw new \Exception( 'Unsupported event type.' );
			}

			$args   = array(
				'limit'          => - 1,
				'payment_method' => $this->id,
				'transaction_id' => esc_attr( $event->transactionReference ),
			);
			$orders = wc_get_orders( $args );
			if ( empty( $orders ) ) {
				throw new \Exception( 'Order retrieval failed.' );
			}
			foreach ( $orders as $wc_order ) {
				$data_to_log['orderId'] = $wc_order->get_id();
				switch ( $event->type ) {
					case EventType::SENT_FOR_SETTLEMENT:
						$event_note = __( 'sent for payment settlement', 'worldpay-ecommerce-woocommerce' );
						$wc_order->payment_complete();
						$wc_order->save();
						break;
					case EventType::ERROR:
						$event_note = __( 'payment was not completed', 'worldpay-ecommerce-woocommerce' );
						break;
					case EventType::REFUSED:
						$event_note = __( 'payment request declined', 'worldpay-ecommerce-woocommerce' );
						break;
					case EventType::SENT_FOR_REFUND:
						$event_note = __( 'payment refund sent', 'worldpay-ecommerce-woocommerce' );
						break;
					case EventType::REFUND_FAILED:
						$event_note = __( 'payment refund failed', 'worldpay-ecommerce-woocommerce' );
						break;
					default:
						throw new \Exception( 'Unsupported event type.' );
				}
				$note_text = sprintf(
					'%s%s %s. Transaction reference: %s' . ( ! empty( $event->reference ) ? '. Partial refund reference %s' : '' ),
					get_woocommerce_currency_symbol( $event->currency ),
					AmountHelper::exponentToDecimalDelimiter( $event->amount ),
					$event_note ?? '',
					$event->transactionReference,
					$event->reference
				);
				$wc_order->add_order_note( $note_text );
				$wc_order->save();
			}
		} catch ( \Exception $e ) {
			$data_to_log = http_build_query( $data_to_log, '', ' | ' );
			$data_to_log .= ' | message=' . $e->getMessage();
			wc_get_logger()->info( $data_to_log );

			return;
		}
	}

	public function process_payment_result_url() {
		$data = $this->get_result_url_params();
		if ( isset( $data['error'] ) ) {
			return wp_safe_redirect( $data['redirect_to'] );
		}

		$result = $this->process_payment_success_url( $data['wc_order'], $data['guid'] );
		if ( false === $result ) {
			$result = $this->process_payment_failure_url( $data['wc_order'], $data['guid'], $data['page'] );
		}

		exit();
	}

	/**
	 * @return array
	 */
	public function get_result_url_params() {
		$page     = empty( $_GET['page'] ) ? '' : wc_clean( wp_unslash( $_GET['page'] ) );
		$guid     = empty( $_GET['guid'] ) ? '' : wc_clean( wp_unslash( $_GET['guid'] ) );
		$order_id = empty( $_GET['order_id'] ) ? '' : wc_clean( wp_unslash( $_GET['order_id'] ) );

		try {
			if ( empty( $guid ) ) {
				throw new \Exception( 'Unable to process payment result url. Invalid guid.' );
			}
			if ( empty( $order_id ) ) {
				throw new \Exception( 'Unable to process payment result url. Invalid order Id.' );
			}
			$wc_order = wc_get_order( $order_id );
			if ( ! $wc_order instanceof WC_Order ) {
				throw new \Exception( 'Unable to process payment result url. Order not found.' );
			}
			if ( $this->id !== $wc_order->get_payment_method() ) {
				throw new \Exception( 'Unable to process payment result url. Payment method not found.' );
			}

			return array(
				'page'     => $page,
				'guid'     => $guid,
				'wc_order' => $wc_order,
			);
		} catch ( \Exception $e ) {
			$data_to_log = array(
				'page'    => $page ?? '',
				'guid'    => $guid ?? '',
				'orderId' => $order_id ?? '',
			);
			$data_to_log = http_build_query( $data_to_log, '', ' | ' );
			$data_to_log .= ' | message=' . $e->getMessage();
			wc_get_logger()->info( $data_to_log );

			$wc_order    = new WC_Order();
			$redirect_to = ( 'checkout' == $page ) ? wc_get_checkout_url() : $wc_order->get_checkout_payment_url();
			wc_get_logger()->info( $redirect_to );

			return array(
				'error'       => true,
				'redirect_to' => add_query_arg( $this->id, 'error', $redirect_to ),
			);
		}
	}

	/**
	 * Process payment success result.
	 *
	 * @param  WC_Order  $wc_order
	 * @param  string  $guid
	 *
	 * @return false
	 */
	public function process_payment_success_url( WC_Order $wc_order, string $guid ) {
		$success_guid = $wc_order->get_meta( 'worldpay_success_guid' );
		if ( $guid === $success_guid ) {
			if ( wc_string_to_bool( $this->get_option( 'app_webhooks' ) ) ) {
				$wc_order->update_status( 'on-hold' );
			} else {
				$wc_order->payment_complete();
			}
			$order_note = sprintf( 'Payment successful via Worldpay. Transaction reference %s',
				$wc_order->get_transaction_id() );
			$wc_order->add_order_note( $order_note );
			$wc_order->save();

			wp_redirect( $wc_order->get_checkout_order_received_url() );
		}

		return false;
	}

	/**
	 *  Process payment failure result in checkout or pay for order.
	 *
	 * @param  WC_Order  $wc_order
	 * @param  string  $guid
	 * @param  string  $page
	 *
	 * @return false
	 */
	public function process_payment_failure_url( WC_Order $wc_order, string $guid, string $page ) {
		$failure_guid = $wc_order->get_meta( 'worldpay_failure_guid' );
		if ( $guid === $failure_guid ) {
			$order_note = sprintf( 'Payment failed via Worldpay. Transaction reference %s',
				$wc_order->get_transaction_id() );
			$wc_order->add_order_note( $order_note );
			$wc_order->delete_meta_data( 'worldpay_transaction_reference' );
			$wc_order->save();

			$redirect_to = ( 'checkout' == $page ) ? wc_get_checkout_url() : $wc_order->get_checkout_payment_url();

			wp_safe_redirect( add_query_arg( $this->id, 'error', $redirect_to ) );
		}

		return false;
	}

	/**
	 * Initialize admin form settings fields.
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$this->form_fields = WC_Access_Worldpay_Form_Fields::init_form_fields();
	}

	/**
	 * Generate html for custom masked password type.
	 *
	 * @param $key
	 * @param $data
	 *
	 * @return false|string
	 */
	public function generate_masked_totally_html( $key, $data ) {
		$data['type'] = 'password';

		return $this->generate_masked_partially_html( $key, $data );
	}

	/**
	 * Generate html for custom masked text type.
	 *
	 * @param $key
	 * @param $data
	 *
	 * @return false|string
	 */
	public function generate_masked_partially_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data        = wp_parse_args( $data, $defaults );
		$field_value = $this->get_option( $key );
		if ( $data["type"] == "password" ) {
			$field_value = $this->limit( $this->mask( $field_value, '*', 0, $this->length( $field_value ) ), 64, '' );
		} else {
			$field_value = $this->mask( $field_value, '*', 0, $this->length( $field_value ) - 4 );
		}

		ob_start();
		?>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?><?php echo $this->get_tooltip_html( $data ); // WPCS: XSS ok.
					?></label>
            </th>
            <td class="forminp">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span>
                    </legend>
                    <input class="input-text regular-input <?php echo esc_attr( $data['class'] ); ?>"
                           type="<?php echo esc_attr( $data['type'] ); ?>" name="<?php echo esc_attr( $field_key ); ?>"
                           id="<?php echo esc_attr( $field_key ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>"
                           value="<?php echo $field_value; ?>"
                           placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'],
						true ); ?> <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok.
					?> />
					<?php echo $this->get_description_html( $data ); ?>
                </fieldset>
            </td>
        </tr>
		<?php

		return ob_get_clean();
	}

	/**
	 * @inheritDoc
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		if ( empty( $amount ) || $amount <= 0 ) {
			throw new \Exception( 'Invalid amount value: ' . $amount );
		}

		try {
			$wc_order = wc_get_order( $order_id );

			$api = $this->initiliaze_api();

			$converted_amount         = AmountHelper::decimalToExponentDelimiter( $amount, $wc_order->get_currency() );
			$partial_refund_reference = Helper::generateString( 12 ) . '-' . $order_id;

			$api_response = $api->refund( $converted_amount )
			                    ->withTransactionReference( $wc_order->get_transaction_id() )
			                    ->withPartialRefundReference( $partial_refund_reference )
			                    ->execute();

			if ( 202 === $api_response->statusCode ) {
				$note_text = sprintf(
					'%s%s sent for payment refund.' . ( ( $amount < $wc_order->get_total() ) ? 'Partial refund reference: %s' : '' ),
					get_woocommerce_currency_symbol( $wc_order->get_currency() ),
					AmountHelper::exponentToDecimalDelimiter( $converted_amount ),
					$partial_refund_reference
				);
				$wc_order->add_order_note( $note_text );

				return true;
			} else {
				throw new \Exception( 'Something went wrong while requesting payment refund.' );
			}
		} catch ( \Exception $e ) {
			$data_to_log = array(
				'requestType'           => 'refund',
				'orderId'               => $order_id ?? null,
				'amount'                => $amount ?? null,
				'convertedAmount'       => $converted_amount ?? null,
				'apiResponseStatusCode' => isset( $api_response ) ? $api_response->statusCode : null,
			);
			$data_to_log = http_build_query( $data_to_log, '', ' | ' );
			$data_to_log .= ' | message=' . $e->getMessage();
			$data_to_log .= isset( $api_response ) ? ' | apiRawResponse=' . $api_response->rawResponse : '';

			wc_get_logger()->info( $data_to_log );

			throw new \Exception( 'Something went wrong while requesting payment refund.' );
		}
	}

	/**
	 * Process a payment.
	 *
	 * @param $order_id
	 *
	 * @return array|void
	 */
	public function process_payment( $order_id ) {
		try {
			$wc_order = wc_get_order( $order_id );

			$api = $this->initiliaze_api();

			$meta_data_transaction_reference = $wc_order->get_meta( 'worldpay_transaction_reference' );
			$transaction_reference           = empty( $meta_data_transaction_reference ) ?
				Helper::generateString( 12 ) :
				$meta_data_transaction_reference;
			$success_guid                    = empty( $meta_data_transaction_reference ) ? wp_generate_uuid4() : $wc_order->get_meta( 'worldpay_success_guid' );
			$failure_guid                    = empty( $meta_data_transaction_reference ) ? wp_generate_uuid4() : $wc_order->get_meta( 'worldpay_failure_guid' );

			$amount       = AmountHelper::decimalToExponentDelimiter( $wc_order->get_total() );
			$results_urls = $this->get_result_urls( $wc_order, $success_guid, $failure_guid );
			$api_response = $api->HPPSetup( $amount )
			                    ->withTransactionReference( $transaction_reference )
			                    ->withOptionalOrder( $this->get_order_data( $wc_order ) )
			                    ->withResultURLs( $results_urls )
			                    ->execute();

			if ( $api_response->statusCode === 200 ) {
				$decodedApiResponse = json_decode( $api_response->rawResponse );
				if ( $decodedApiResponse === null && json_last_error() !== JSON_ERROR_NONE ) {
					throw new \Exception( 'Malformed JSON response received.' );
				}
				$hppURL = $decodedApiResponse->url;

				$transaction_id = $transaction_reference . '_' . $order_id;
				$note_text      = sprintf(
					'%s%s awaiting payment via Worldpay. Transaction reference %s',
					get_woocommerce_currency_symbol( $wc_order->get_currency() ),
					AmountHelper::exponentToDecimalDelimiter( $amount ),
					$transaction_id
				);
				$wc_order->update_status( 'pending' );
				$wc_order->add_order_note( $note_text );
				$wc_order->set_transaction_id( $transaction_id );

				$wc_order->add_meta_data( 'worldpay_success_guid', $success_guid, true );
				$wc_order->add_meta_data( 'worldpay_failure_guid', $failure_guid, true );
				$wc_order->add_meta_data( 'worldpay_transaction_reference', $transaction_reference, true );
				$wc_order->save_meta_data();

				$wc_order->save();

				return [
					'result'   => 'success',
					'redirect' => esc_url_raw( $hppURL ),
				];

			} else {
				throw new \Exception( 'Unable to retrieve payment URL.' );
			}
		} catch ( Exception $e ) {
			if ( isset( $api_response ) && wc_string_to_bool( $this->get_option( 'app_debug' ) ) ) {
				wc_get_logger()->info( $api_response->rawRequest );
				wc_get_logger()->info( $api_response->statusCode . ' | ' . $api_response->rawResponse );
			}
			wc_get_logger()->debug( 'orderId=' . $order_id . ' | ' . $e->getMessage() );

			throw new \Exception( 'Something went wrong while processing payment. Please try again.' );
		}
	}

	/**
	 * Initialize PHP SDK for payment gateway.
	 *
	 * @return AccessWorldpay
	 */
	public function initiliaze_api() {
		WC_Worldpay_Ecommerce_Woocommerce::include_sdk();

		return AccessWorldpay::config( $this->configure_api() );
	}

	/**
	 * Configure API for payment gateway request.
	 *
	 * @return AccessWorldpayConfigProvider|null
	 */
	public function configure_api() {
		$api_config_provider                    = AccessWorldpayConfigProvider::instance();
		$api_config_provider->environment       = $this->get_api_environment();
		$api_config_provider->username          = $this->get_api_username();
		$api_config_provider->password          = $this->get_api_password();
		$api_config_provider->merchantEntity    = $this->get_merchant_entity();
		$api_config_provider->merchantNarrative = $this->get_merchant_narrative();

		$this->configure_proxy();

		return $api_config_provider;
	}

	/**
	 * Configure proxy for API requests.
	 *
	 * @return void
	 */
	public function configure_proxy() {
		$proxy_config_provider = ProxyConfigProvider::instance();

		$wp_proxy = new WP_HTTP_Proxy();
		if ( $wp_proxy->is_enabled() ) {
			$proxy_config_provider->host = $wp_proxy->host();
			$proxy_config_provider->port = $wp_proxy->port();
			if ( $wp_proxy->use_authentication() ) {
				$proxy_config_provider->proxyUsername = $wp_proxy->username();
				$proxy_config_provider->proxyPassword = $wp_proxy->password();
			}
		}
	}

	/**
	 * Get API environment - test or live.
	 *
	 * @return string
	 */
	public function get_api_environment() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			Environment::LIVE_MODE :
			Environment::TRY_MODE;
	}

	/**
	 * Get API username for test or live environment.
	 *
	 * @return string
	 */
	public function get_api_username() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			$this->get_option( 'app_api_live_username' ) :
			$this->get_option( 'app_api_try_username' );
	}

	/**
	 * Get API password for test or live environment.
	 *
	 * @return string
	 */
	public function get_api_password() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			$this->get_option( 'app_api_live_password' ) :
			$this->get_option( 'app_api_try_password' );
	}

	/**
	 * Get API merchant entity.
	 *
	 * @return string
	 */
	public function get_merchant_entity() {
		return $this->get_option( 'app_merchant_entity' );
	}

	/**
	 * Get API merchant narrative.
	 *
	 * @return string
	 */
	public function get_merchant_narrative() {
		return $this->get_option( 'app_merchant_narrative' );
	}

	/**
	 * Get order data for API order initialization.
	 *
	 * @param  WC_Order  $wc_order
	 *
	 * @return Order
	 */
	public function get_order_data( WC_Order $wc_order ) {
		$wc_order_data              = $wc_order->get_data();
		$api_order                  = new Order();
		$api_order->id              = $wc_order->get_id();
		$api_order->billingAddress  = $this->get_order_address( $wc_order->get_id(), $wc_order_data, 'billing' );
		$api_order->shippingAddress = $this->get_order_address( $wc_order->get_id(), $wc_order_data, 'shipping' );
		$api_order->customer        = $this->get_order_customer( $wc_order_data );

		return $api_order;
	}

	/**
	 * Get billing/shipping address for API order initialization.
	 *
	 * @param  array  $wc_order_data
	 * @param  string  $address_type
	 *
	 * @return BillingAddress|ShippingAddress
	 */
	public function get_order_address( int $order_id, array $wc_order_data, string $address_type ) {
		$api_address              = $address_type == 'billing' ?
			new BillingAddress() :
			new ShippingAddress();
		$api_address->address1    = $wc_order_data[ $address_type ]['address_1'] ?? '';
		$api_address->address2    = $wc_order_data[ $address_type ]['address_2'] ?? '';
		$api_address->address3    = '';
		$api_address->postalCode  = $wc_order_data[ $address_type ]['postcode'] ?? '';
		$api_address->city        = $wc_order_data[ $address_type ]['city'] ?? '';
		$api_address->state       = $wc_order_data[ $address_type ]['state'] ?? '';
		$api_address->countryCode = get_post_meta( $order_id, '_' . $address_type . '_country', true ) ?? '';

		return $api_address;
	}

	/**
	 * Get customer details for API order initialization.
	 *
	 * @param  array  $wc_order_data
	 *
	 * @return Customer
	 */
	public function get_order_customer( array $wc_order_data ) {
		$api_customer              = new Customer();
		$api_customer->firstName   = $wc_order_data['billing']['first_name'] ?? '';
		$api_customer->lastName    = $wc_order_data['billing']['last_name'] ?? '';
		$api_customer->email       = $wc_order_data['billing']['email'] ?? '';
		$api_customer->phoneNumber = $wc_order_data['billing']['phone'] ?? '';

		return $api_customer;
	}

	/**
	 * Get result urls for payment processing
	 *
	 * @param  WC_Order  $wc_order
	 * @param  string  $success_guid
	 * @param  string  $failure_guid
	 *
	 * @return ResultURLs
	 */
	public function get_result_urls( WC_Order $wc_order, string $success_guid, string $failure_guid ) {
		$resultUrls = new ResultURLs();


		$resultUrls->cancelURL = is_checkout_pay_page() ? $wc_order->get_checkout_payment_url() : wc_get_checkout_url();

		$page = is_checkout_pay_page() ? 'orderpay' : 'checkout';
		$resultUrls->successURL = add_query_arg( 'page', $page, WC()->api_request_url( 'worldpay_results', true ) );
		$resultUrls->successURL = add_query_arg( 'order_id', $wc_order->get_id(), $resultUrls->successURL );
		$resultUrls->successURL = add_query_arg( 'guid', $success_guid, $resultUrls->successURL );

		$resultUrls->failureURL = add_query_arg( 'page', $page, WC()->api_request_url( 'worldpay_results' ), true );
		$resultUrls->failureURL = add_query_arg( 'order_id', $wc_order->get_id(), $resultUrls->failureURL );
		$resultUrls->failureURL = add_query_arg( 'guid', $failure_guid, $resultUrls->failureURL );

		$resultUrls->errorURL   = $resultUrls->failureURL;
		$resultUrls->expiryURL  = $resultUrls->failureURL;
		$resultUrls->pendingURL = $resultUrls->failureURL;

		return $resultUrls;
	}

	/**
	 * Check if payment method is available for checkout or pay for order display.
	 *
	 * @return bool
	 */
	public function is_available() {
		$order_id = absint( get_query_var( 'order-pay' ) );
		if ( $order_id > 0 ) {
			$wc_order = wc_get_order( $order_id );
			if ( in_array( $wc_order->get_currency(), [ 'GBP' ] ) ) {
				return parent::is_available();
			}
		}

		if ( ! in_array( get_woocommerce_currency(), [ 'GBP' ] ) ) {
			return false;
		}

		return parent::is_available();
	}

}

/**
 * Add Worldway to payment options for WooCommerce.
 *
 * @param $methods
 *
 * @return mixed
 */
function add_worldpay_gateway( $methods ) {
	$methods[] = 'WC_Payment_Gateway_Access_Worldpay';

	return $methods;
}

add_filter( 'woocommerce_payment_gateways', 'add_worldpay_gateway' );
